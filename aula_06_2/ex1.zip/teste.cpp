#include "RedeSocial.h"

void teste() {
  RedeSocial* rede = new RedeSocial();

  Perfil* p1 = new PessoaVerificada("Nelson Rodrigues", "nelson.rodrigues@usp.br", 10);
  Perfil* p2 = new Perfil("Gabriela Ferreira", 10);

  rede->adicionar(p1);
  rede->adicionar(p2);

  p1->adicionarContato(p2);

  p1->publicar("Mensagem N1", 1);
  p2->publicar("Mensagem G1", 2);

  rede->imprimir();

  delete rede;
}
