#include "Perfil.h"

void imprimirRede(Perfil** perfis, int quantidade) {
    cout << "==================================" << endl;
    for (int i = 0; i < quantidade; i++) {
    perfis[i]->imprimir();
    }
}

void teste() {
    Perfil *perfis[3];

    perfis[0] = new Perfil;
    perfis[0]->setNome("Maria");
    
    perfis[1] = new Perfil;
    perfis[1]->setNome("Antonio");

    perfis[2] = new Perfil;
    perfis[2]->setNome("Carlos");

    perfis[1]->adicionarContato(perfis[0]);
    perfis[2]->adicionarContato(perfis[0]);
    perfis[1]->adicionarContato(perfis[2]);

    perfis[1]->adicionarPostagem("Mensagem 1");
    perfis[2]->adicionarPostagem("Mensagem 2");

    imprimirRede(perfis, 3);
}

// int main(void) {
//     teste();

//     return 0;
// }