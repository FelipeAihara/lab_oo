#include <iostream>

#ifndef PERFIL_H
#define PERFIL_H

#define MAXIMO_POSTAGENS 20
#define MAXIMO_CONTATOS 20

using namespace std;

class Perfil {
private: 
    string nome;
    Perfil* contatos[MAXIMO_CONTATOS];
    int quantidadeDeContatos = 0;
    string postagens[MAXIMO_POSTAGENS];
    int quantidadeDePostagens = 0;

public:
    bool adicionarContato(Perfil* contato);
    bool adicionarPostagem(string texto);
    void imprimir();
    string getNome();
    void setNome(string nome);
    int getQuantidadeDeContatos();
    int getQuantidadeDePostagens();
    Perfil** getContatos();
    string* getPostagens();
};

#endif