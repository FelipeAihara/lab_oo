 /* Faca os includes adequados!
 */
#ifndef PERSONAGEM_H
#include "Personagem.h"
#endif

/**
 * Implementar as funcoes teste
 **/

void teste1() {
    // IMPLEMENTE seguindo o enunciado
    Personagem *p1 = new Personagem("Link", 100, 50);
    p1->mostrarAtributos();
    delete p1;
}

void teste2() {
    // IMPLEMENTE seguindo o enunciado
}
