/*
 * Faca os includes necessários e complete a implementacao dos metodos aqui!
 */

#include "Jogo.h"
#include <iostream>
using namespace std;
 
Jogo::Jogo (Personagem* p){
}


void Jogo::adicionarMonstro(Personagem* monstro){
}

void Jogo::lutar(Personagem* monstro){
}

int Jogo::jogar(){
  // Complete o código e altere o valor de retorno
  return 0;
}

int Jogo::getQuantidadeDeMonstros() {
  // Complete o código e altere o valor de retorno
  return 0;
}

Personagem** Jogo::getMonstros() {
  // Complete o código e altere o valor de retorno
  return NULL;
}

Personagem* Jogo::getJogador() {
  // Complete o código e altere o valor de retorno
  return NULL;
}
